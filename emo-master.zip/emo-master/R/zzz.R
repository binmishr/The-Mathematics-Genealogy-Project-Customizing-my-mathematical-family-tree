#' @importFrom utils globalVariables
globalVariables(c(".", "emoji"))
