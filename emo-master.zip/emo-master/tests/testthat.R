library(testthat)
library(emo)

test_check("emo")
